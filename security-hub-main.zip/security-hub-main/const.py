# This key will serve all examples in this document.
KEY = "acd2fa6813bc417b9a9085bf266685d3"

# This endpoint will be used in all examples in this quickstart.
ENDPOINT = "https://securityface.cognitiveservices.azure.com/"

# Set users

DANIEL_NAME = 'Daniel Ye'
OBI_NAME = 'Obi Abii'
LIAM_NAME = 'Liam Arzola'

USERS = [DANIEL_NAME, OBI_NAME, LIAM_NAME]