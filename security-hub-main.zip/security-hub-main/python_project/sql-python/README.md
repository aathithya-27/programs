# Cosmos DB Python sample

Customize the [config.py](./config.py) file with your account host and key.